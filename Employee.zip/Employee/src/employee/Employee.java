package employee;

import org.junit.Test;
import static org.junit.Assert.assertEquals;
import org.junit.runner.JUnitCore;
import org.junit.runner.Result;
import org.junit.runner.notification.Failure;

class EmployeeDetails {

    private String name;
    private String DOB;
    private float Salary, apparisal;

    public EmployeeDetails(String name, String Dob, float Salary) {
        this.name = name;
        this.DOB = Dob;
        this.Salary = Salary;
    }

    public String getName() {
        return this.name;
    }

    public String getDob() {
        return this.DOB;
    }

    public float getMonthlySalary() {
        return this.Salary;
    }

    public float calculateAppraisal() {
        this.apparisal = 0;
        if (this.getMonthlySalary() > 10000) {
            return this.apparisal = 1000;
        } else {
            return this.apparisal = 500;
        }
    }

   public double calculateYearlySalary() {
        return this.getMonthlySalary() * 12;
    }
}

class TestEmployeeDetails {

    EmployeeDetails emp = new EmployeeDetails("Rajeev", "10-09-1998", 8000);
    double appraisal = emp.calculateAppraisal();

    //assertEquals(500,appraisal,0.0);
    @Test
    public void testCalculateAppriasal() {
        double appraisal = emp.calculateAppraisal();
        assertEquals(500, appraisal, 0.0);
    }

    // test to check yearly salary
    @Test
    public void testCalculateYearlySalary() {
        double salary = emp.calculateYearlySalary();
        assertEquals(96000, salary, 0.0);
    }
}

public class Employee {

    public static void main(String[] args) {
        EmployeeDetails empdetail = new EmployeeDetails("Avan", "10-09-1998", 8000);
        System.out.println(empdetail.calculateAppraisal());
        // TODO code application logic here
        System.out.println("ckdsjfug");
        Result result = JUnitCore.runClasses(TestEmployeeDetails.class);
        for (Failure failure : result.getFailures()) {
            System.out.println(failure.toString());
        }
        System.out.println(result.wasSuccessful());
    }

}
